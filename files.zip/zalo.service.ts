// =============================================================
//  zalo.service.ts — Bắn tin Zalo (ZNS template / OA message) bằng axios
//  Tài liệu: https://developers.zalo.me  (ZNS & Official Account Message API)
// =============================================================
import axios from 'axios';
import { ZALO } from '../config';

export interface ZaloSendResult {
  ok: boolean;
  channel: 'zns' | 'oa';
  provider_response?: unknown;
  error?: string;
}

/**
 * Gửi cẩm nang sửa lỗi tới số Zalo của KTS.
 * - Mode "zns": dùng template ZNS đã được duyệt (khuyến nghị cho thông báo chính thức).
 * - Mode "oa": gửi tin nhắn văn bản qua Official Account (yêu cầu user đã quan tâm OA).
 */
export async function guiCamNangZalo(
  phone: string,
  hoTen: string,
  doChinhXac: number,
  camNang: string
): Promise<ZaloSendResult> {
  // Chuẩn hoá số: Zalo dùng định dạng quốc gia 84xxxxxxxxx
  const to = chuanHoaSdt(phone);

  if (!ZALO.accessToken) {
    return { ok: false, channel: ZALO.sendMode, error: 'Chưa cấu hình ZALO_OA_ACCESS_TOKEN.' };
  }

  try {
    if (ZALO.sendMode === 'zns') {
      // ---- ZNS: gửi theo template ----
      const res = await axios.post(
        'https://business.openapi.zalo.me/message/template',
        {
          phone: to,
          template_id: ZALO.znsTemplateId,
          template_data: {
            ho_ten: hoTen,
            do_chinh_xac: `${doChinhXac}%`,
            // Tuỳ template ZNS của bạn map thêm field. Cẩm nang dài nên kèm link tải đầy đủ.
            tom_tat: camNang.slice(0, 200),
          },
          tracking_id: `recruit_${Date.now()}`,
        },
        { headers: { access_token: ZALO.accessToken, 'Content-Type': 'application/json' } }
      );
      const ok = res.data?.error === 0;
      return { ok, channel: 'zns', provider_response: res.data, error: ok ? undefined : res.data?.message };
    }

    // ---- OA: gửi tin nhắn văn bản thường ----
    const res = await axios.post(
      'https://openapi.zalo.me/v3.0/oa/message/cs',
      {
        recipient: { user_id: to },
        message: { text: camNang },
      },
      { headers: { access_token: ZALO.accessToken, 'Content-Type': 'application/json' } }
    );
    const ok = res.data?.error === 0;
    return { ok, channel: 'oa', provider_response: res.data, error: ok ? undefined : res.data?.message };
  } catch (err: any) {
    return {
      ok: false,
      channel: ZALO.sendMode,
      error: err?.response?.data ? JSON.stringify(err.response.data) : err?.message ?? 'Lỗi gửi Zalo',
    };
  }
}

function chuanHoaSdt(phone: string): string {
  let p = String(phone).replace(/\D/g, '');
  if (p.startsWith('0')) p = '84' + p.slice(1);
  if (!p.startsWith('84')) p = '84' + p;
  return p;
}
