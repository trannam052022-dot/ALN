// =============================================================
//  db.ts — Kết nối MySQL vật lý (mysql2/promise pool)
// =============================================================
import mysql from 'mysql2/promise';
import { DB } from './config';

export const pool = mysql.createPool({
  host: DB.host,
  port: DB.port,
  user: DB.user,
  password: DB.password,
  database: DB.database,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  charset: 'utf8mb4_unicode_ci',
});

// Kiểm tra kết nối lúc khởi động (gọi trong server.ts)
export async function pingDb(): Promise<void> {
  const conn = await pool.getConnection();
  try {
    await conn.ping();
    console.log('[DB] Kết nối MySQL thành công:', DB.database);
  } finally {
    conn.release();
  }
}
