// =============================================================
//  contract.service.ts — Ký hợp đồng điện tử thành công:
//  (1) INSERT KTS vào bảng ChuyenGia (ACTIVE, uy tín 5.0)
//  (2) Gọi webhook OAuth sang applamnha.vn để cấp quyền truy cập
// =============================================================
import axios from 'axios';
import crypto from 'crypto';
import { pool } from '../db';
import { WEBHOOK, PHI_SAN_PCT, THUE_PCT, BoMonList } from './constants';
import type { BoMon } from './layerCheck.service';

export interface OnboardInput {
  ho_ten: string;
  sdt_zalo: string;
  email?: string;
  bo_mon: BoMon;
}

export interface OnboardResult {
  ma_kts: string;
  trang_thai: 'ACTIVE';
  diem_uy_tin: number;
  webhook: { ok: boolean; status?: number; error?: string };
}

/** Sinh mã KTS dạng KTS-xxxx-xxxx (ngẫu nhiên, viết hoa). */
function sinhMaKts(): string {
  const block = () => crypto.randomBytes(2).toString('hex').toUpperCase(); // 4 ký tự hex
  return `KTS-${block()}-${block()}`;
}

/** Token nội bộ ký theo HMAC để webhook bên kia verify được nguồn gốc. */
function kyToken(payload: object): string {
  const body = Buffer.from(JSON.stringify(payload)).toString('base64');
  const sig = crypto.createHmac('sha256', WEBHOOK.secret).update(body).digest('hex');
  return `${body}.${sig}`;
}

export async function onboardChuyenGia(input: OnboardInput): Promise<OnboardResult> {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    // Chống trùng số điện thoại đã kích hoạt
    const [exist] = await conn.query('SELECT id FROM ChuyenGia WHERE sdt_zalo = ?', [input.sdt_zalo]);
    if ((exist as any[]).length > 0) {
      throw new Error('Số điện thoại này đã được kích hoạt tài khoản KTS trước đó.');
    }

    const maKts = sinhMaKts();
    await conn.query(
      `INSERT INTO ChuyenGia
        (ma_kts, ho_ten, sdt_zalo, email, bo_mon, diem_uy_tin, trang_thai, phi_san_pct, thue_pct)
       VALUES (?, ?, ?, ?, ?, 5.0, 'ACTIVE', ?, ?)`,
      [maKts, input.ho_ten, input.sdt_zalo, input.email ?? null, input.bo_mon, PHI_SAN_PCT, THUE_PCT]
    );

    await conn.commit();

    // ---- Gọi webhook cấp quyền OAuth sang applamnha.vn ----
    const webhook = await kichHoatQuyen({ ma_kts: maKts, ...input });

    return { ma_kts: maKts, trang_thai: 'ACTIVE', diem_uy_tin: 5.0, webhook };
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
}

async function kichHoatQuyen(payload: {
  ma_kts: string; ho_ten: string; sdt_zalo: string; email?: string; bo_mon: BoMon;
}): Promise<{ ok: boolean; status?: number; error?: string }> {
  try {
    const token = kyToken({ ...payload, scope: 'KTS_ACTIVE', ts: Date.now() });
    const res = await axios.post(
      WEBHOOK.url,
      { ...payload, scope: 'KTS_ACTIVE' },
      {
        headers: {
          Authorization: `Bearer ${token}`,
          'X-ALN-Source': 'recruitment-agent',
          'Content-Type': 'application/json',
        },
        timeout: 10000,
      }
    );
    return { ok: res.status >= 200 && res.status < 300, status: res.status };
  } catch (err: any) {
    return { ok: false, status: err?.response?.status, error: err?.message ?? 'Webhook lỗi' };
  }
}

// re-export để route dùng kiểm tra bộ môn hợp lệ
export { BoMonList };
