// =============================================================
//  layerCheck.service.ts — Lõi sàng lọc kỹ thuật
//  Đối chiếu Layer KTS nộp (3 bộ bản vẽ) với bảng chuẩn BanVe_DrawLayer,
//  tính độ chính xác, sinh "Cẩm nang hướng dẫn chi tiết" khi sai.
// =============================================================
import { pool } from '../db';

export type BoMon = 'ARC' | 'STR' | 'ELE' | 'PLU';

export interface LayerInput {
  ten_lop: string;
  ma_mau_he_thong: string;
  kieu_net_ve: string;
}

export interface DrawingSet {
  ten_bo_ban_ve: string; // ví dụ "Nhà phố 5x20 — Kinh tế"
  layers: LayerInput[];
}

export interface LayerError {
  ten_lop: string;
  loai_loi: 'THIEU_LAYER' | 'SAI_MA_MAU' | 'SAI_KIEU_NET';
  ky_vong: { ma_mau_he_thong: string; kieu_net_ve: string };
  thuc_te: { ma_mau_he_thong?: string; kieu_net_ve?: string } | null;
  huong_dan: string;
}

export interface SetResult {
  ten_bo_ban_ve: string;
  do_chinh_xac: number; // %
  so_layer_chuan: number;
  so_layer_dat: number;
  loi: LayerError[];
}

export interface CheckResult {
  bo_mon: BoMon;
  do_chinh_xac_tong: number; // % trung bình 3 bộ
  dat_chuan: boolean;
  ket_qua: 'PASSED_TECHNICAL' | 'PENDING_REVISION';
  chi_tiet_bo: SetResult[];
  cam_nang: string; // văn bản cẩm nang gửi Zalo (rỗng nếu đạt)
}

const norm = (s: string) => String(s ?? '').trim().toUpperCase();

/** Lấy bộ chuẩn layer của một bộ môn từ DB vật lý. */
async function loadStandard(boMon: BoMon): Promise<Array<LayerInput & { bat_buoc: number }>> {
  const [rows] = await pool.query(
    'SELECT ten_lop, ma_mau_he_thong, kieu_net_ve, bat_buoc FROM BanVe_DrawLayer WHERE bo_mon = ? AND bat_buoc = 1',
    [boMon]
  );
  return rows as Array<LayerInput & { bat_buoc: number }>;
}

/** Đối chiếu 1 bộ bản vẽ với chuẩn. */
function checkOneSet(set: DrawingSet, standard: Array<LayerInput & { bat_buoc: number }>): SetResult {
  const submittedByName = new Map<string, LayerInput>();
  for (const l of set.layers) submittedByName.set(norm(l.ten_lop), l);

  const loi: LayerError[] = [];
  let dat = 0;

  for (const std of standard) {
    const sub = submittedByName.get(norm(std.ten_lop));
    if (!sub) {
      loi.push({
        ten_lop: std.ten_lop,
        loai_loi: 'THIEU_LAYER',
        ky_vong: { ma_mau_he_thong: std.ma_mau_he_thong, kieu_net_ve: std.kieu_net_ve },
        thuc_te: null,
        huong_dan: `Thiếu layer "${std.ten_lop}". Hãy tạo layer này với mã màu ${std.ma_mau_he_thong} và kiểu nét ${std.kieu_net_ve}.`,
      });
      continue;
    }
    const saiMau = norm(sub.ma_mau_he_thong) !== norm(std.ma_mau_he_thong);
    const saiNet = norm(sub.kieu_net_ve) !== norm(std.kieu_net_ve);

    if (saiMau) {
      loi.push({
        ten_lop: std.ten_lop,
        loai_loi: 'SAI_MA_MAU',
        ky_vong: { ma_mau_he_thong: std.ma_mau_he_thong, kieu_net_ve: std.kieu_net_ve },
        thuc_te: { ma_mau_he_thong: sub.ma_mau_he_thong, kieu_net_ve: sub.kieu_net_ve },
        huong_dan: `Layer "${std.ten_lop}" sai mã màu: bạn dùng ${sub.ma_mau_he_thong}, chuẩn ALN là ${std.ma_mau_he_thong}.`,
      });
    }
    if (saiNet) {
      loi.push({
        ten_lop: std.ten_lop,
        loai_loi: 'SAI_KIEU_NET',
        ky_vong: { ma_mau_he_thong: std.ma_mau_he_thong, kieu_net_ve: std.kieu_net_ve },
        thuc_te: { ma_mau_he_thong: sub.ma_mau_he_thong, kieu_net_ve: sub.kieu_net_ve },
        huong_dan: `Layer "${std.ten_lop}" sai kiểu nét: bạn dùng ${sub.kieu_net_ve}, chuẩn ALN là ${std.kieu_net_ve}.`,
      });
    }
    if (!saiMau && !saiNet) dat += 1; // layer đạt khi đúng CẢ mã màu VÀ kiểu nét
  }

  const soChuan = standard.length || 1;
  return {
    ten_bo_ban_ve: set.ten_bo_ban_ve,
    so_layer_chuan: standard.length,
    so_layer_dat: dat,
    do_chinh_xac: Math.round((dat / soChuan) * 10000) / 100,
    loi,
  };
}

/** Sinh "Cẩm nang hướng dẫn chi tiết" dạng văn bản (gửi Zalo). */
function buildCamNang(hoTen: string, boMon: BoMon, tong: number, sets: SetResult[]): string {
  const dong: string[] = [];
  dong.push(`📐 CẨM NANG SỬA LỖI CẤU TRÚC LAYER — ALN`);
  dong.push(`Chào ${hoTen}, bộ môn ${boMon}. Độ chính xác hiện tại: ${tong}% (cần ≥ 80%).`);
  dong.push(``);
  for (const s of sets) {
    if (s.loi.length === 0) {
      dong.push(`✅ ${s.ten_bo_ban_ve}: ${s.do_chinh_xac}% — đạt.`);
      continue;
    }
    dong.push(`⚠️ ${s.ten_bo_ban_ve}: ${s.do_chinh_xac}% — cần sửa ${s.loi.length} điểm:`);
    s.loi.forEach((e, i) => dong.push(`   ${i + 1}. ${e.huong_dan}`));
    dong.push(``);
  }
  dong.push(`Định dạng chuẩn mỗi layer: tên_lop · mã_màu_hệ_thống · kiểu_nét_vẽ.`);
  dong.push(`Sửa xong, nộp lại tại kts.applamnha.vn để qua vòng kỹ thuật.`);
  return dong.join('\n');
}

/**
 * Hàm chính: đối chiếu 3 bộ bản vẽ của KTS với chuẩn bộ môn.
 * dat_chuan khi độ chính xác trung bình >= ngưỡng (mặc định 80%).
 */
export async function checkBlueprints(
  hoTen: string,
  boMon: BoMon,
  drawingSets: DrawingSet[],
  threshold: number
): Promise<CheckResult> {
  const standard = await loadStandard(boMon);
  if (standard.length === 0) {
    throw new Error(`Chưa cấu hình chuẩn Layer cho bộ môn ${boMon} trong BanVe_DrawLayer.`);
  }

  const chiTiet = drawingSets.map((set) => checkOneSet(set, standard));
  const tong =
    Math.round((chiTiet.reduce((s, c) => s + c.do_chinh_xac, 0) / chiTiet.length) * 100) / 100;
  const datChuan = tong >= threshold;

  return {
    bo_mon: boMon,
    do_chinh_xac_tong: tong,
    dat_chuan: datChuan,
    ket_qua: datChuan ? 'PASSED_TECHNICAL' : 'PENDING_REVISION',
    chi_tiet_bo: chiTiet,
    cam_nang: datChuan ? '' : buildCamNang(hoTen, boMon, tong, chiTiet),
  };
}
