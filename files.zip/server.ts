// =============================================================
//  server.ts — Khởi động Express (CommonJS / TypeScript)
// =============================================================
import express from 'express';
import cors from 'cors';
import { SERVER } from './config';
import { pingDb } from './db';
import recruitmentRoutes from './routes/recruitment.routes';

const app = express();
app.use(cors());
app.use(express.json({ limit: '2mb' }));

// Healthcheck
app.get('/health', (_req, res) => res.json({ ok: true, service: 'ALN Recruitment Agent', ts: Date.now() }));

// Phân hệ tuyển dụng
app.use('/api/v1/recruitment', recruitmentRoutes);

// 404
app.use((_req, res) => res.status(404).json({ ok: false, message: 'Không tìm thấy endpoint.' }));

async function start() {
  try {
    await pingDb();
  } catch (e) {
    console.error('[DB] Cảnh báo: chưa kết nối được MySQL. Server vẫn chạy.', (e as Error).message);
  }
  app.listen(SERVER.PORT, () => {
    console.log(`🏛️  ALN Recruitment Agent đang chạy: http://localhost:${SERVER.PORT}`);
    console.log(`    POST /api/v1/recruitment/submit-blueprints`);
    console.log(`    POST /api/v1/recruitment/verify-otp-contract`);
  });
}

start();
