# NỘI DUNG TUYỂN DỤNG — LÀM NHÀ STUDIO AI (ALN)
### Mô hình "Uber KTS & Kỹ sư" · Điều hướng: **kts.applamnha.vn**

> Định vị tâm lý: KTS truyền thống mất tiền vì **bị nợ, bị quỵt cọc, sửa vô tận không công, bị giam vốn**.
> ALN bán lại đúng thứ họ thiếu: **dòng tiền Escrow VNĐ tự nhảy số theo từng chặng — có làm, có tiền, không sợ bùng.**

---

## A. BÀI ĐĂNG TUYỂN DỤNG (Facebook Group / Cộng đồng KTS)

**Tiêu đề:**
> Bạn đã vẽ xong cả bộ hồ sơ — còn chủ nhà thì "biến mất". Lần thứ mấy rồi?

Mình hỏi thật, anh chị nào trong nghề mà chưa từng dính một trong mấy "đặc sản" này:

- Giao bản vẽ xong, chủ nhà hẹn "cuối tháng chuyển" — rồi cuối tháng đó kéo dài 6 tháng.
- Cọc 30% nhưng làm tới 90% khối lượng, đòi thì bị nói "chưa ưng".
- "Sửa nhẹ thôi mà" — sửa tới lần thứ 14, không thêm một đồng.
- Tiền nằm trong túi chủ nhà, còn rủi ro nằm hết trong tay mình.

Nghề mình giỏi chuyên môn, nhưng **dở nhất khoản đòi tiền**. Và mình không nên giỏi khoản đó — mình nên giỏi thiết kế.

**LÀM NHÀ STUDIO AI (ALN)** dựng lại luật chơi bằng đúng một thứ: **Sổ cái Khế ước (Escrow Ledger) bằng VNĐ.**

Tiền chủ nhà nạp vào tài khoản ký quỹ trước khi bạn đặt nét đầu tiên. Bạn làm xong chặng nào, hệ thống **tự nhảy số giải ngân chặng đó**:

| Chặng | Hạng mục | % giải ngân |
|------|----------|------------|
| **C1** | Ý tưởng mặt bằng 2D | **10%** |
| **C2** | Phối cảnh 3D | **20%** |
| **C3** | Hồ sơ kỹ thuật thi công | **60%** |
| **C4** | Bảo hành (giữ lại, tự nhả sau 90 ngày) | **10%** |

Không có chuyện "làm xong mới biết có được trả hay không". Tiền đã nằm sẵn trong két ký quỹ — **bạn duyệt chặng, tiền về tài khoản.**

**Sòng phẳng tới từng con số:**
- Phí nền tảng **20%** cố định, ghi rõ trong hợp đồng — không phí ẩn.
- Thuế dịch vụ **7%** (5% GTGT + 2% TNCN) khấu trừ tại nguồn, có chứng từ.
- Bạn luôn biết chính xác mình **nhận net bao nhiêu** trước khi bấm nhận lệnh.

**Kỷ luật 2 chiều — bảo vệ cả bạn:**
- SLA phản hồi **48 giờ**. Chủ nhà ngâm quá hạn, hệ thống đứng về phía bạn.
- Chủ nhà khiếu nại vô căn cứ → CEO cưỡng chế giải ngân cho KTS.
- Sửa đổi có **giới hạn số lần miễn phí** ghi trong hợp đồng. Quá hạn mức = tính phí. Hết thời "sửa vô tận".

**Bạn cần gì để vào sàn:**
- Bằng kiến trúc / kỹ sư xây dựng (CCHN là một lợi thế lên hạng PRO/VIP).
- Nộp **3 bộ hồ sơ "Gói kinh tế"** đạt **chuẩn Layer ALN** (ARC / STR / ELE / PLU).
- Một số Zalo để nhận cẩm nang sửa lỗi tự động nếu bản vẽ chưa đạt.

Bản vẽ chưa chuẩn? Không loại bạn. Hệ thống **bắn thẳng cẩm nang sửa lỗi vào Zalo** của bạn — sai lớp nào, sai mã màu nào, sai kiểu nét nào, sửa thế nào. Đạt ≥ 80% là qua vòng kỹ thuật, ký hợp đồng điện tử bằng OTP, kích hoạt tài khoản ngay.

👉 **Nộp hồ sơ tại: kts.applamnha.vn**
Có làm, có tiền. Đúng nghĩa.

*(Hashtag gợi ý: #LamNhaStudioAI #KTS #EscrowVND #KhongSoBung #UberKTS)*

---

## B. KỊCH BẢN VIDEO NGẮN (TikTok / Reels · < 60 giây)

**Concept:** Một KTS ngồi trước màn hình lúc 1h sáng, tin nhắn đòi tiền "đã xem, không trả lời". Đối lập: màn hình ALN tiền tự nhảy số.
**Tổng thời lượng:** ~52 giây. **Tông:** thật, hơi cay, kết thúc dứt khoát.

| Time | HÌNH ẢNH (Visual) | LỜI THOẠI / VOICEOVER | CHỮ ON-SCREEN |
|------|-------------------|----------------------|----------------|
| 0:00–0:04 | Cận cảnh màn hình chat: "Bản vẽ ok rồi, để cuối tháng anh gửi nhé" — seen, im lặng. | *(Tiếng gõ phím dừng lại)* "Lần thứ ba… cùng một câu." | LẦN THỨ 3 RỒI |
| 0:04–0:10 | KTS dụi mắt, xung quanh là bản in hồ sơ chất đống. | "Mình vẽ giỏi. Nhưng đòi tiền thì… dở tệ." | VẼ GIỎI · ĐÒI TIỀN DỞ |
| 0:10–0:18 | Lướt nhanh: bản vẽ sửa lần 1, lần 5, lần 12… đỏ hết ghi chú. | "Sửa tới lần 12. Không thêm một đồng. Cọc thì giữ nguyên 30%." | SỬA VÔ TẬN = LÀM KHÔNG CÔNG |
| 0:18–0:24 | Cắt đen. Logo ALN sáng lên. | "Rồi mình đổi sân chơi." | — |
| 0:24–0:34 | Màn hình ALN: chủ nhà nạp tiền vào **Escrow VNĐ** TRƯỚC. Thanh C1→C2→C3 sáng dần, số tiền tự nhảy. | "Tiền nằm sẵn trong két ký quỹ. Mình làm xong chặng nào — tiền chặng đó tự về." | ESCROW VNĐ · CÓ LÀM CÓ TIỀN |
| 0:34–0:42 | Hiển thị dòng net: Tổng chặng − Phí sàn 20% − Thuế 7% = **Thực nhận**. | "Phí sàn 20%, thuế 7% — ghi rõ. Mình biết chính xác cầm về bao nhiêu." | SÒNG PHẲNG TỪNG SỐ |
| 0:42–0:48 | Đồng hồ SLA 48h đếm ngược; chủ nhà ngâm quá hạn → hệ thống đứng về phía KTS. | "Không ai bùng được mình nữa." | KHÔNG SỢ BÙNG |
| 0:48–0:52 | KTS gập laptop, nhẹ nhõm. Tên miền hiện lớn. | "Nộp hồ sơ. Vào sàn. Bắt đầu được trả tiền tử tế." | **kts.applamnha.vn** |

**Caption đăng kèm:**
> Bạn không cần học cách đòi tiền. Bạn cần một sàn mà tiền **tự về** sau mỗi chặng. Escrow VNĐ — có làm, có tiền, không sợ bùng. Nộp hồ sơ: kts.applamnha.vn
> #LamNhaStudioAI #KTS #Escrow #ThietKeNha #UberKTS

**Ghi chú dựng:**
- Nhịp cắt nhanh ở đoạn "pain" (0:00–0:18), giãn nhịp ở đoạn giải pháp (0:24–0:42) để khán giả kịp đọc con số.
- Nhạc: lo-fi trầm ở đoạn đầu → beat dứt khoát từ giây 0:24.
- Số tiền minh hoạ nên dùng số tròn (vd 50.000.000đ) để thanh giải ngân "nhảy số" rõ ràng.
