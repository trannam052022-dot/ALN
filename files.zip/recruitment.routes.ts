// =============================================================
//  recruitment.routes.ts — Phân hệ tuyển dụng ALN
//  ENDPOINT 1: POST /api/v1/recruitment/submit-blueprints
//  ENDPOINT 2: POST /api/v1/recruitment/verify-otp-contract
// =============================================================
import { Router, Request, Response } from 'express';
import { pool } from '../db';
import {
  PASS_THRESHOLD,
  DIEU_KHOAN_HOP_DONG,
  PHI_SAN_PCT,
  THUE_PCT,
} from '../config';
import { checkBlueprints, DrawingSet, BoMon } from '../services/layerCheck.service';
import { guiCamNangZalo } from '../services/zalo.service';
import { issueOtp, verifyOtp } from '../services/otp.service';
import { onboardChuyenGia } from '../services/contract.service';
import { BoMonList } from '../services/constants';

const router = Router();

// ---------------------------------------------------------------
//  ENDPOINT 1 — Nộp 3 bộ bản vẽ, sàng lọc kỹ thuật
// ---------------------------------------------------------------
router.post('/submit-blueprints', async (req: Request, res: Response) => {
  try {
    const { ho_ten, sdt_zalo, email, bo_mon, drawing_sets } = req.body ?? {};

    // ---- Validate ----
    if (!ho_ten || !sdt_zalo || !bo_mon || !Array.isArray(drawing_sets)) {
      return res.status(400).json({
        ok: false,
        message: 'Thiếu trường bắt buộc: ho_ten, sdt_zalo, bo_mon, drawing_sets[].',
      });
    }
    if (!BoMonList.includes(bo_mon)) {
      return res.status(400).json({ ok: false, message: `Bộ môn không hợp lệ. Chọn 1 trong: ${BoMonList.join(', ')}.` });
    }
    if (drawing_sets.length !== 3) {
      return res.status(400).json({ ok: false, message: 'Gói kinh tế yêu cầu đúng 3 bộ bản vẽ.' });
    }

    // ---- Đối chiếu chuẩn Layer ----
    const result = await checkBlueprints(ho_ten, bo_mon as BoMon, drawing_sets as DrawingSet[], PASS_THRESHOLD);

    // ---- Ghi log audit ----
    await pool.query(
      `INSERT INTO HoSoNopBanVe (ho_ten, sdt_zalo, email, bo_mon, do_chinh_xac, ket_qua, chi_tiet_loi)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [
        ho_ten, sdt_zalo, email ?? null, bo_mon,
        result.do_chinh_xac_tong, result.ket_qua,
        JSON.stringify(result.chi_tiet_bo),
      ]
    );

    // ---- CHƯA ĐẠT: gửi cẩm nang Zalo, trả PENDING_REVISION ----
    if (!result.dat_chuan) {
      const zalo = await guiCamNangZalo(sdt_zalo, ho_ten, result.do_chinh_xac_tong, result.cam_nang);
      return res.status(200).json({
        ok: true,
        status: 'PENDING_REVISION',
        do_chinh_xac: result.do_chinh_xac_tong,
        nguong_dat: PASS_THRESHOLD,
        cam_nang: result.cam_nang,
        chi_tiet_bo: result.chi_tiet_bo,
        zalo_da_gui: zalo.ok,
        zalo_kenh: zalo.channel,
        zalo_loi: zalo.error,
        message: 'Bản vẽ chưa đạt chuẩn. Đã gửi cẩm nang sửa lỗi vào Zalo của bạn.',
      });
    }

    // ---- ĐẠT CHUẨN: sinh OTP, chờ ký hợp đồng ----
    const otp = issueOtp(sdt_zalo, { ho_ten, sdt_zalo, email, bo_mon });
    // Production: KHÔNG trả OTP trong response — gửi qua Zalo/SMS.
    // Ở đây trả kèm để phục vụ kiểm thử/onboarding theo yêu cầu đề bài.
    return res.status(200).json({
      ok: true,
      status: 'PASSED_TECHNICAL',
      do_chinh_xac: result.do_chinh_xac_tong,
      nguong_dat: PASS_THRESHOLD,
      chi_tiet_bo: result.chi_tiet_bo,
      otp, // ⚠ chỉ trả ở môi trường test
      message: 'Đạt chuẩn kỹ thuật. Nhập OTP để ký hợp đồng điện tử.',
    });
  } catch (err: any) {
    console.error('[submit-blueprints]', err);
    return res.status(500).json({ ok: false, message: err?.message ?? 'Lỗi hệ thống.' });
  }
});

// ---------------------------------------------------------------
//  ENDPOINT 2 — Xác thực OTP & ký hợp đồng điện tử
// ---------------------------------------------------------------
router.post('/verify-otp-contract', async (req: Request, res: Response) => {
  try {
    const { sdt_zalo, otp } = req.body ?? {};
    if (!sdt_zalo || !otp) {
      return res.status(400).json({ ok: false, message: 'Thiếu sdt_zalo hoặc otp.' });
    }

    // ---- Xác thực OTP ----
    const check = verifyOtp(sdt_zalo, otp);
    if (!check.ok) {
      return res.status(401).json({ ok: false, message: check.reason });
    }

    const meta = check.meta as { ho_ten: string; sdt_zalo: string; email?: string; bo_mon: BoMon };

    // ---- INSERT ChuyenGia + gọi webhook OAuth ----
    const onboard = await onboardChuyenGia({
      ho_ten: meta.ho_ten,
      sdt_zalo: meta.sdt_zalo,
      email: meta.email,
      bo_mon: meta.bo_mon,
    });

    return res.status(201).json({
      ok: true,
      status: 'CONTRACT_SIGNED',
      ma_kts: onboard.ma_kts,
      diem_uy_tin: onboard.diem_uy_tin,
      trang_thai: onboard.trang_thai,
      hop_dong: {
        phi_san_pct: PHI_SAN_PCT,
        thue_pct: THUE_PCT,
        dieu_khoan: DIEU_KHOAN_HOP_DONG,
      },
      cap_quyen_oauth: onboard.webhook, // kết quả gọi applamnha.vn
      message: 'Ký hợp đồng thành công. Tài khoản KTS đã được kích hoạt.',
    });
  } catch (err: any) {
    console.error('[verify-otp-contract]', err);
    return res.status(500).json({ ok: false, message: err?.message ?? 'Lỗi hệ thống.' });
  }
});

export default router;
