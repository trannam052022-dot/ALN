// =============================================================
//  otp.service.ts — Sinh & xác thực OTP (Session/Cache in-memory có TTL)
//  Lưu ý production: thay Map bằng Redis để scale nhiều instance.
// =============================================================
import { OTP_TTL_SECONDS } from '../config';

interface OtpRecord {
  otp: string;
  expiresAt: number; // epoch ms
  attempts: number;  // số lần nhập sai
  meta?: Record<string, unknown>; // thông tin KTS kèm theo để INSERT khi ký HĐ
}

const store = new Map<string, OtpRecord>();
const MAX_ATTEMPTS = 5;

/** Sinh OTP 6 số ngẫu nhiên, lưu vào cache theo số điện thoại. */
export function issueOtp(phone: string, meta?: Record<string, unknown>): string {
  const otp = String(Math.floor(100000 + Math.random() * 900000)); // 6 số
  store.set(normalize(phone), {
    otp,
    expiresAt: Date.now() + OTP_TTL_SECONDS * 1000,
    attempts: 0,
    meta,
  });
  return otp;
}

/** Xác thực OTP. Trả về { ok, reason, meta }. Khớp xong sẽ xoá khỏi cache. */
export function verifyOtp(phone: string, otp: string): {
  ok: boolean; reason?: string; meta?: Record<string, unknown>;
} {
  const key = normalize(phone);
  const rec = store.get(key);
  if (!rec) return { ok: false, reason: 'OTP không tồn tại hoặc đã được sử dụng.' };
  if (Date.now() > rec.expiresAt) {
    store.delete(key);
    return { ok: false, reason: 'OTP đã hết hạn. Vui lòng yêu cầu mã mới.' };
  }
  if (rec.attempts >= MAX_ATTEMPTS) {
    store.delete(key);
    return { ok: false, reason: 'Nhập sai quá số lần cho phép. Mã đã bị huỷ.' };
  }
  if (rec.otp !== String(otp).trim()) {
    rec.attempts += 1;
    return { ok: false, reason: `OTP không đúng. Còn ${MAX_ATTEMPTS - rec.attempts} lần thử.` };
  }
  store.delete(key); // dùng một lần
  return { ok: true, meta: rec.meta };
}

function normalize(phone: string): string {
  return String(phone).replace(/\s+/g, '').trim();
}
