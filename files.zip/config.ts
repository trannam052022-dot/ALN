// =============================================================
//  config.ts — TIÊU CHUẨN LÕI HỆ THỐNG (ALN)
//  Tập trung mọi hằng số nghiệp vụ về một nơi để dễ đối chiếu Điều lệ.
// =============================================================
import dotenv from 'dotenv';
dotenv.config();

export const SERVER = {
  PORT: Number(process.env.PORT ?? 4000),
};

export const DB = {
  host: process.env.DB_HOST ?? '127.0.0.1',
  port: Number(process.env.DB_PORT ?? 3306),
  user: process.env.DB_USER ?? 'root',
  password: process.env.DB_PASSWORD ?? '',
  database: process.env.DB_NAME ?? 'lamnha_studio',
};

export const ZALO = {
  accessToken: process.env.ZALO_OA_ACCESS_TOKEN ?? '',
  znsTemplateId: process.env.ZALO_ZNS_TEMPLATE_ID ?? '',
  sendMode: (process.env.ZALO_SEND_MODE ?? 'zns') as 'zns' | 'oa',
};

export const WEBHOOK = {
  url: process.env.APPLAMNHA_WEBHOOK_URL ?? 'https://applamnha.vn/api/internal/grant-access',
  secret: process.env.APPLAMNHA_WEBHOOK_SECRET ?? '',
};

// ---- Dòng tiền Escrow VNĐ: 4 chặng 10-20-60-10 ----
export const ESCROW_STAGES = [
  { ma: 'C1', ten: 'Ý tưởng mặt bằng 2D', pct: 10 },
  { ma: 'C2', ten: 'Phối cảnh 3D',         pct: 20 },
  { ma: 'C3', ten: 'Hồ sơ kỹ thuật',       pct: 60 },
  { ma: 'C4', ten: 'Bảo hành giữ lại',     pct: 10 },
] as const;

// ---- Tài chính sòng phẳng ----
export const PHI_SAN_PCT = 20;   // ⚠ ĐỐI CHIẾU ĐIỀU LỆ: Gói Kinh tế dùng mô hình bán nội dung số (~80% ALN).
export const THUE_PCT = 7;       // 5% GTGT + 2% TNCN (Nghị định 91/2022/NĐ-CP)

// ---- Kỷ luật thép SLA ----
export const SLA_GIO = 48;                 // đồng hồ đếm ngược phản hồi 48h
export const PHAT_GAY_VANG = -0.1;         // trừ điểm uy tín mỗi lần trễ
export const GAY_VANG_DOI_GAY_DO = 3;      // 3 Gậy Vàng = 1 Gậy Đỏ
export const GAY_DO_KHOA_NGAY = 14;        // ⚠ ĐỐI CHIẾU ĐIỀU LỆ: Điều 22 nêu khóa 90 ngày

// ---- Vòng sàng lọc kỹ thuật ----
export const PASS_THRESHOLD = Number(process.env.PASS_THRESHOLD ?? 80); // %
export const OTP_TTL_SECONDS = Number(process.env.OTP_TTL_SECONDS ?? 300);

// ---- Điều khoản pháp lý bắt buộc của hợp đồng điện tử ----
export const DIEU_KHOAN_HOP_DONG = [
  `Cam kết khấu trừ Thuế dịch vụ Việt Nam ${THUE_PCT}% (5% GTGT + 2% TNCN) tại nguồn trên mỗi giao dịch.`,
  `Cam kết Phí nền tảng (phí sàn) ${PHI_SAN_PCT}% trên mỗi giao dịch.`,
  `Dòng tiền giải ngân qua Sổ cái Khế ước (Escrow Ledger) theo 4 chặng 10-20-60-10%.`,
  `Tuân thủ SLA phản hồi ${SLA_GIO} giờ; vi phạm áp dụng thang chế tài Gậy Vàng / Gậy Đỏ.`,
  `Không giao dịch ngoài sàn với Chủ nhà đã kết nối qua ALN.`,
];

// Công thức KTS nhận net theo Điều lệ:
// net = TienChang - PhiSan - (TienChang - PhiSan) * Thue%
export function tinhThucNhan(tienChang: number): {
  phiSan: number; thue: number; thucNhan: number;
} {
  const phiSan = Math.round((tienChang * PHI_SAN_PCT) / 100);
  const conLai = tienChang - phiSan;
  const thue = Math.round((conLai * THUE_PCT) / 100);
  return { phiSan, thue, thucNhan: conLai - thue };
}
