# ALN — Recruitment, Layer Standardization & Legal Agent

Phân hệ backend tuyển dụng KTS cho **Làm Nhà Studio AI** (mô hình Uber KTS & Kỹ sư): sàng lọc chuẩn Layer → gửi cẩm nang sửa lỗi qua Zalo → ký hợp đồng điện tử bằng OTP → cấp quyền OAuth.

## Cấu trúc
```
src/
  server.ts                     # bootstrap Express
  config.ts                     # tiêu chuẩn lõi: Escrow, phí 20%, thuế 7%, SLA, chế tài
  db.ts                         # MySQL pool (mysql2/promise)
  db/schema.sql                 # tạo DB + bảng BanVe_DrawLayer, ChuyenGia, HoSoNopBanVe + seed
  routes/recruitment.routes.ts  # 2 endpoint
  services/
    layerCheck.service.ts       # đối chiếu layer, tính độ chính xác, sinh cẩm nang
    zalo.service.ts             # gửi ZNS / OA bằng axios
    otp.service.ts              # sinh/xác thực OTP (cache TTL)
    contract.service.ts         # INSERT ChuyenGia + webhook OAuth applamnha.vn
    constants.ts                # bộ môn hợp lệ + re-export hằng số
tuyendung_agent.html            # giao diện kiểm thử offline (đặt ở thư mục gốc deliverable)
```

## Cài đặt
```bash
cp .env.example .env          # điền MySQL, Zalo token, webhook secret
npm install
mysql -u root -p < src/db/schema.sql   # tạo DB + seed chuẩn layer
npm run dev                   # hoặc: npm run build && npm start
```

## Tiêu chuẩn lõi (sửa tại `src/config.ts`)
- Escrow 4 chặng: C1 10% · C2 20% · C3 60% · C4 10%
- Phí sàn 20% · Thuế 7% (5% GTGT + 2% TNCN)
- SLA 48h · Gậy Vàng −0.1 · 3 Gậy Vàng = 1 Gậy Đỏ (khóa 14 ngày)
- Ngưỡng đạt chuẩn kỹ thuật: 80%

> ⚠ Các dòng có chú thích `// ⚠ ĐỐI CHIẾU ĐIỀU LỆ` là điểm vênh giữa spec và Điều lệ ALN — cân nhắc thống nhất.

## Test nhanh (curl)

### 1) Nộp bản vẽ — trường hợp SAI (nhận cẩm nang + gửi Zalo)
```bash
curl -X POST http://localhost:4000/api/v1/recruitment/submit-blueprints \
 -H 'Content-Type: application/json' \
 -d '{
  "ho_ten":"Nguyễn Văn A","sdt_zalo":"0901234567","email":"a@mail.com","bo_mon":"ARC",
  "drawing_sets":[
    {"ten_bo_ban_ve":"Bộ 1","layers":[
      {"ten_lop":"ARC_TUONG","ma_mau_he_thong":"99","kieu_net_ve":"DASHED"}
    ]},
    {"ten_bo_ban_ve":"Bộ 2","layers":[]},
    {"ten_bo_ban_ve":"Bộ 3","layers":[]}
  ]
 }'
# -> status: PENDING_REVISION, kèm cam_nang, zalo_da_gui
```

### 2) Nộp bản vẽ — trường hợp ĐẠT (>=80%) → nhận OTP
Điền đủ các layer đúng `ma_mau_he_thong` + `kieu_net_ve` theo seed trong `schema.sql`
(ARC: ARC_TUONG=31/CHẮC CHẮN, ARC_CUA=5/CONTINUOUS, ARC_NOITHAT=3/SAY MÊ, ARC_KICHTHUOC=2/CONTINUOUS).
```
# -> status: PASSED_TECHNICAL, otp: "xxxxxx"
```

### 3) Ký hợp đồng bằng OTP
```bash
curl -X POST http://localhost:4000/api/v1/recruitment/verify-otp-contract \
 -H 'Content-Type: application/json' \
 -d '{"sdt_zalo":"0901234567","otp":"123456"}'
# -> status: CONTRACT_SIGNED, ma_kts, cap_quyen_oauth
```

## Lưu ý production
- OTP đang trả trong response để phục vụ kiểm thử — production phải gửi qua Zalo/SMS, không trả ra client.
- Thay cache OTP `Map` bằng Redis khi chạy nhiều instance.
- Webhook OAuth ký HMAC-SHA256 bằng `APPLAMNHA_WEBHOOK_SECRET`; phía applamnha.vn verify chữ ký trước khi cấp quyền.
