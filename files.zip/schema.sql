-- =============================================================
--  LÀM NHÀ STUDIO AI (ALN) — Recruitment Schema
--  Tạo database + 3 bảng vật lý + seed Layer Standard 4 bộ môn
-- =============================================================
CREATE DATABASE IF NOT EXISTS lamnha_studio
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE lamnha_studio;

-- -------------------------------------------------------------
--  1) BẢNG CHUẨN LAYER (nguồn đối chiếu vật lý)
--     Định dạng chuẩn: ten_lop, ma_mau_he_thong, kieu_net_ve
--     bo_mon: ARC (Kiến trúc) | STR (Kết cấu) | ELE (Điện) | PLU (Cấp thoát nước)
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS BanVe_DrawLayer (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  bo_mon          ENUM('ARC','STR','ELE','PLU') NOT NULL,
  ten_lop         VARCHAR(120) NOT NULL,
  ma_mau_he_thong VARCHAR(40)  NOT NULL,   -- ví dụ mã màu theo hệ thống: "31", "1", "5"... hoặc HEX
  kieu_net_ve     VARCHAR(60)  NOT NULL,   -- CONTINUOUS, "CHẮC CHẮN", "SAY MÊ", DASHED...
  bat_buoc        TINYINT(1)   NOT NULL DEFAULT 1, -- layer bắt buộc tính vào độ chính xác
  created_at      TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_bomon_tenlop (bo_mon, ten_lop)
) ENGINE=InnoDB;

-- -------------------------------------------------------------
--  2) BẢNG CHUYÊN GIA (KTS được kích hoạt sau khi ký HĐ)
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS ChuyenGia (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  ma_kts        VARCHAR(24) NOT NULL UNIQUE,           -- KTS-xxxx-xxxx
  ho_ten        VARCHAR(120) NOT NULL,
  sdt_zalo      VARCHAR(20)  NOT NULL UNIQUE,
  email         VARCHAR(160),
  bo_mon        ENUM('ARC','STR','ELE','PLU') NOT NULL,
  diem_uy_tin   DECIMAL(3,1) NOT NULL DEFAULT 5.0,     -- khởi tạo 5.0
  trang_thai    ENUM('ACTIVE','LOCKED','PENDING') NOT NULL DEFAULT 'ACTIVE',
  phi_san_pct   DECIMAL(4,1) NOT NULL DEFAULT 20.0,    -- 20% theo spec (⚠ đối chiếu Điều lệ)
  thue_pct      DECIMAL(4,1) NOT NULL DEFAULT 7.0,     -- 5% GTGT + 2% TNCN
  ngay_ky_hd    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
  created_at    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- -------------------------------------------------------------
--  3) LOG NỘP HỒ SƠ (audit vòng sàng lọc kỹ thuật)
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS HoSoNopBanVe (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  ho_ten          VARCHAR(120) NOT NULL,
  sdt_zalo        VARCHAR(20)  NOT NULL,
  email           VARCHAR(160),
  bo_mon          ENUM('ARC','STR','ELE','PLU') NOT NULL,
  do_chinh_xac    DECIMAL(5,2) NOT NULL,               -- %
  ket_qua         ENUM('PASSED_TECHNICAL','PENDING_REVISION') NOT NULL,
  chi_tiet_loi    JSON,                                -- cẩm nang lỗi (nếu có)
  created_at      TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_sdt (sdt_zalo)
) ENGINE=InnoDB;

-- =============================================================
--  SEED — Bộ chuẩn Layer tối thiểu cho 4 bộ môn (ví dụ vận hành)
--  Có thể mở rộng tuỳ tiêu chuẩn nội bộ ALN.
-- =============================================================
INSERT INTO BanVe_DrawLayer (bo_mon, ten_lop, ma_mau_he_thong, kieu_net_ve, bat_buoc) VALUES
-- ARC — Kiến trúc
('ARC','ARC_TUONG',        '31', 'CHẮC CHẮN',  1),
('ARC','ARC_CUA',          '5',  'CONTINUOUS', 1),
('ARC','ARC_NOITHAT',      '3',  'SAY MÊ',     1),
('ARC','ARC_KICHTHUOC',    '2',  'CONTINUOUS', 1),
('ARC','ARC_TRUC',         '1',  'CENTER',     0),
-- STR — Kết cấu
('STR','STR_COT',          '1',  'CHẮC CHẮN',  1),
('STR','STR_DAM',          '4',  'CONTINUOUS', 1),
('STR','STR_THEP',         '2',  'SAY MÊ',     1),
('STR','STR_MONG',         '6',  'CONTINUOUS', 1),
-- ELE — Điện
('ELE','ELE_ODIEN',        '3',  'CONTINUOUS', 1),
('ELE','ELE_DAYDAN',       '4',  'SAY MÊ',     1),
('ELE','ELE_DEN',          '2',  'CONTINUOUS', 1),
('ELE','ELE_TUDIEN',       '1',  'CHẮC CHẮN',  1),
-- PLU — Cấp thoát nước
('PLU','PLU_CAPNUOC',      '5',  'CONTINUOUS', 1),
('PLU','PLU_THOATNUOC',    '3',  'SAY MÊ',     1),
('PLU','PLU_THIETBI',      '2',  'CONTINUOUS', 1),
('PLU','PLU_ONGDUNG',      '6',  'CHẮC CHẮN',  1)
ON DUPLICATE KEY UPDATE
  ma_mau_he_thong = VALUES(ma_mau_he_thong),
  kieu_net_ve     = VALUES(kieu_net_ve),
  bat_buoc        = VALUES(bat_buoc);
