// =============================================================
//  constants.ts — Hằng số dùng chung cho tầng service
// =============================================================
export { WEBHOOK, PHI_SAN_PCT, THUE_PCT } from '../config';

export const BoMonList = ['ARC', 'STR', 'ELE', 'PLU'] as const;
export type BoMonType = (typeof BoMonList)[number];
